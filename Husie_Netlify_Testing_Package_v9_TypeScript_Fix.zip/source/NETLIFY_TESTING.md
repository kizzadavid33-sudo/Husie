# Husie — Netlify testing package

This package prepares the Husie Next.js web app for a Netlify test deployment. Netlify can provide a temporary `*.netlify.app` URL, so a custom domain is not required for the first visual check.

## Important architecture note

Husie is a monorepo with two separate services:

- `apps/web`: Next.js web app (the part configured for Netlify)
- `apps/api`: independent Fastify API, which connects to PostgreSQL and persistent media storage

Netlify can host the Next.js web app, but this configuration does **not** automatically deploy the Fastify API, PostgreSQL database, or persistent media storage. Until `MIRROR_GRAM_API_URL` points to a reachable running Husie API, account registration, authenticated feeds, messaging, uploads, private circles, and other backend-backed functions will not work. Do not use the site for real user data until the API and database are configured.

## Deploy

1. Extract this ZIP on a computer.
2. Open Netlify and create a new site from the extracted project using the repository/Git method, or use Netlify's project upload flow if available for your account.
3. Netlify should use the root `netlify.toml`; the build command is `npm run build:web`.
4. Set `MIRROR_GRAM_API_URL` in the Netlify site environment variables to the **public base URL** of a running Husie API (for example `https://api.example.com`). Do not use `127.0.0.1` or `localhost` for a deployed site.
5. Redeploy after setting the environment variable.

If no API is available yet, deploy only as a preliminary frontend/build check. The Netlify-generated URL is enough for visual checks of public screens, but it is not a complete working social network.

## API / CORS / session notes

- The web app forwards `/api/*` and `/media/*` requests to `MIRROR_GRAM_API_URL` through the Next.js rewrite configuration.
- Keep web and API on HTTPS in the deployed setup.
- Test sign-up/login, session cookies, media upload/delivery, and account deletion only after the API and database are running and the API's allowed-origin/session-cookie settings match the deployed web URL.
- Never commit production passwords, session secrets, database credentials, or private keys into this ZIP or source control.

## Build status

This ZIP contains deployment configuration and instructions. It has not been verified by a successful Netlify build or production integration test in this environment. The Next.js app's dependency installation previously timed out here, so Netlify's build log must be checked after the first deployment.
