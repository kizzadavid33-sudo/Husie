# Netlify build fix — v9

Fixed the TypeScript `noImplicitAny` error in `apps/web/app/components/HusieCard.tsx` by explicitly typing the `setLikes` state updater parameter as `number`.

This addresses the specific compiler error shown in the Netlify log. A full production build has not been run in this environment, so additional build errors may still be reported after redeploying.

## Redeploy
1. Download and extract this ZIP.
2. In Netlify, open the Husie project.
3. Use the manual deploy flow to upload the extracted project folder (the folder containing `netlify.toml` and the root `package.json`) or connect the source repository and commit the change.
4. Check the deploy log. If another error appears, share the new log so it can be fixed precisely.
